/**
 * protocol stuff with GUI dependecies
 */
/**
 * @author erwin
 *
 */
package com.fr3ts0n.prot.gui;