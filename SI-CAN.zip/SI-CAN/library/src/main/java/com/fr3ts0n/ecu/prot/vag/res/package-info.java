/**
 * VAG specific protocol resources
 * @author fr3ts0n
 */
package com.fr3ts0n.ecu.prot.vag.res;