/**
 * VAG specific protocol stuff
 *
 * @author fr3ts0n
 */
package com.fr3ts0n.ecu.prot.vag;