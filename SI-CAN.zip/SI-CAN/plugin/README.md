# AndrOBD-libplugin
Plugin extension library which is shared between plugin and host application
